
public class ClientUserName {

	public static boolean flag = false;
	public static int count = 0;
	public static void main(String[] args)
	{
		while(true)
		{
			if(flag)
			{
				count++;
				System.out.println(count);
				flag = false;
			}
		}
	}
}
