
public class test {

	static int x = 0;

	public test()
	{
		x++;
	}

	public static void main(String[] args)
	{
		test t1 = new test();
	     System.out.println(t1.x);
	}
	
}
