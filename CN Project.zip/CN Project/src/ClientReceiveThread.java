import java.io.IOException;
import java.util.HashMap;

public class ClientReceiveThread implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		final Thread receiveThread = new Thread(){
			public void run() {
				try 
				{
					try {
						out.flush();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					SelectTask st = new SelectTask();
					while(true)
					{
						Object obj = st.select_task(); 
						if(obj==null)
						{
							return;
						}
						else
						{
							HashMap<Integer,String[]> map = (HashMap<Integer,String[]>)obj;
							send_to_server(map);
						}
									
					}
				}finally
				{
					System.out.println("received Everything. Bye.");
				}
			}
		};
		
		receiveThread.run();
	}

	
	
}
